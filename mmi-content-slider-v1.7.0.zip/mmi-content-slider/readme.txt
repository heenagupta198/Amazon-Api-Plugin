=== MMI Content Slider ===
Contributors: mymobileindia
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.7.0
License: GPLv2 or later

Link news articles on the main site to device products and show a Latest News carousel on WooCommerce product pages (multisite /devices/).

== Installation ==

1. Upload the `mmi-content-slider` folder to `wp-content/plugins/` on the network (or both sites).
2. Network-activate the plugin (recommended) or activate on the main news site and the Devices subsite.
3. Edit a news post on the main site — use the **Linked Device Products** box in the sidebar (below other meta boxes such as AMP).
4. Search by product name or numeric ID, add one or more devices, and publish.
5. Open that product on `https://www.mymobileindia.com/devices/` — **Related Articles** appears just above ReHub **Related Products** (`#related-section-woo-area`).
6. Activate this plugin on **both** WordPress installs (English news + Devices). News stores the links; Devices renders the carousel.

== Notes ==

* Product IDs are from the Devices subsite WooCommerce catalog (`post_type` product).
* Blog IDs auto-detect: main site = news, path `/devices/` = products. Override with network options `mmi_csl_devices_blog_id` and `mmi_csl_news_blog_id` if needed.
* v1.2.0: Select2 multi-select, fast title SQL search (works with short tokens like X8), rate limiting + query cache, reverse index on products for Latest News on `/devices/`.
* After upgrading to 1.2.0, open each linked article and click **Update** once to refresh the device index (or only new/edited posts sync automatically).
