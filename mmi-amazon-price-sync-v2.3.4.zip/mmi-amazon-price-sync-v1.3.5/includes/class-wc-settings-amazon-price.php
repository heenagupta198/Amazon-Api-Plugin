<?php
/**
 * WooCommerce settings tab: Amazon Price Sync.
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WC_Settings_Page' ) ) {
	return;
}

class MMI_APS_WC_Settings_Amazon_Price extends WC_Settings_Page {

	public function __construct() {
		$this->id    = 'mmi_amazon_price_sync';
		$this->label = __( 'Amazon Price Sync', 'mmi-amazon-price-sync' );

		parent::__construct();
	}

	/**
	 * @return array<int,array<string,mixed>>
	 */
	public function get_settings(): array {
		$using_constant = defined( 'MMI_APS_RAPIDAPI_KEY' ) && MMI_APS_RAPIDAPI_KEY;

		$settings = array(
			array(
				'title' => __( 'Amazon price API', 'mmi-amazon-price-sync' ),
				'type'  => 'title',
				'desc'  => __( 'Choose RapidAPI or Amazon Creators API — the saved provider is used for all sync.', 'mmi-amazon-price-sync' ),
				'id'    => 'mmi_aps_api_options',
			),
			array(
				'title'   => __( 'Price API provider', 'mmi-amazon-price-sync' ),
				'id'      => MMI_APS_Settings::OPTION_API_PROVIDER,
				'type'    => 'select',
				'default' => 'rapidapi',
				'options' => array(
					'rapidapi' => __( 'RapidAPI', 'mmi-amazon-price-sync' ),
					'creators' => __( 'Amazon Creators API', 'mmi-amazon-price-sync' ),
				),
			),
		);

		if ( $using_constant ) {
			$settings[] = array(
				'title' => __( 'RapidAPI Key', 'mmi-amazon-price-sync' ),
				'type'  => 'mmi_aps_constant_notice',
				'id'    => 'mmi_aps_rapidapi_key_notice',
			);
		} else {
			$settings[] = array(
				'title'    => __( 'RapidAPI Key', 'mmi-amazon-price-sync' ),
				'desc'     => __( 'Your x-rapidapi-key from the RapidAPI dashboard.', 'mmi-amazon-price-sync' ),
				'id'       => MMI_APS_Settings::OPTION_API_KEY,
				'type'     => 'password',
				'default'  => '',
				'desc_tip' => true,
				'autoload' => false,
			);
		}

		$settings = array_merge(
			$settings,
			array(
				array(
					'title'    => __( 'RapidAPI Host', 'mmi-amazon-price-sync' ),
					'desc'     => __( 'x-rapidapi-host header value.', 'mmi-amazon-price-sync' ),
					'id'       => MMI_APS_Settings::OPTION_API_HOST,
					'type'     => 'text',
					'default'  => MMI_APS_Settings::DEFAULT_HOST,
					'desc_tip' => true,
				),
				array(
					'title'    => __( 'API Endpoint Path', 'mmi-amazon-price-sync' ),
					'desc'     => __( 'Path appended to the host, e.g. /amazon/product-details', 'mmi-amazon-price-sync' ),
					'id'       => MMI_APS_Settings::OPTION_API_ENDPOINT,
					'type'     => 'text',
					'default'  => MMI_APS_Settings::DEFAULT_ENDPOINT,
					'desc_tip' => true,
				),
				array(
					'title'    => __( 'Amazon Country', 'mmi-amazon-price-sync' ),
					'desc'     => __( 'Marketplace country code sent to the API (IN for Amazon India).', 'mmi-amazon-price-sync' ),
					'id'       => MMI_APS_Settings::OPTION_COUNTRY,
					'type'     => 'text',
					'default'  => 'IN',
					'desc_tip' => true,
				),
				array(
					'type' => 'sectionend',
					'id'   => 'mmi_aps_api_options',
				),
				array(
					'title' => __( 'How it works', 'mmi-amazon-price-sync' ),
					'type'  => 'title',
					'desc'  => '<ol style="margin-left:1.2em;">'
						. '<li>' . esc_html__( 'Add an Amazon ASIN on each WooCommerce product (Product Data → Amazon Price tab).', 'mmi-amazon-price-sync' ) . '</li>'
						. '<li>' . esc_html__( 'Click "Fetch Price" to pull the live Amazon India price via RapidAPI.', 'mmi-amazon-price-sync' ) . '</li>'
						. '<li>' . esc_html__( 'Amazon price, original price, and last-updated time are saved as product meta.', 'mmi-amazon-price-sync' ) . '</li>'
						. '<li>' . esc_html__( 'The storefront shows the Amazon price automatically — your manual WooCommerce price is not overwritten.', 'mmi-amazon-price-sync' ) . '</li>'
						. '</ol>'
						. '<p><code>define( \'MMI_APS_RAPIDAPI_KEY\', \'your-key-here\' );</code> ' . esc_html__( 'in wp-config.php overrides the key stored here.', 'mmi-amazon-price-sync' ) . '</p>',
					'id'    => 'mmi_aps_howto',
				),
				array(
					'type' => 'sectionend',
					'id'   => 'mmi_aps_howto',
				),
				array(
					'title' => __( 'Amazon Creators API', 'mmi-amazon-price-sync' ),
					'type'  => 'title',
					'id'    => 'mmi_aps_creators_options',
				),
				array(
					'title' => __( 'Credential ID', 'mmi-amazon-price-sync' ),
					'id'    => MMI_APS_Settings::OPTION_CREATORS_CLIENT_ID,
					'type'  => 'text',
				),
				array(
					'title' => __( 'Credential Secret', 'mmi-amazon-price-sync' ),
					'id'    => MMI_APS_Settings::OPTION_CREATORS_CLIENT_SECRET,
					'type'  => 'password',
				),
				array(
					'title'   => __( 'API version', 'mmi-amazon-price-sync' ),
					'id'      => MMI_APS_Settings::OPTION_CREATORS_VERSION,
					'type'    => 'text',
					'default' => MMI_APS_Settings::DEFAULT_CREATORS_VERSION,
				),
				array(
					'title'   => __( 'Marketplace', 'mmi-amazon-price-sync' ),
					'id'      => MMI_APS_Settings::OPTION_MARKETPLACE,
					'type'    => 'text',
					'default' => MMI_APS_Settings::DEFAULT_MARKETPLACE,
				),
				array(
					'type' => 'sectionend',
					'id'   => 'mmi_aps_creators_options',
				),
				array(
					'title' => __( 'Storefront (91mobiles layout)', 'mmi-amazon-price-sync' ),
					'type'  => 'title',
					'id'    => 'mmi_aps_storefront_options',
				),
				array(
					'title'   => __( 'Show PRICES tab', 'mmi-amazon-price-sync' ),
					'id'      => MMI_APS_Settings::OPTION_SHOW_PRICES_TAB,
					'type'    => 'checkbox',
					'default' => 'yes',
				),
				array(
					'title'   => __( 'Show SPECS tab', 'mmi-amazon-price-sync' ),
					'id'      => MMI_APS_Settings::OPTION_SHOW_SPECS_TAB,
					'type'    => 'checkbox',
					'default' => 'yes',
				),
				array(
					'title'   => __( 'Show extra SPECS tab (attributes)', 'mmi-amazon-price-sync' ),
					'desc'    => __( 'WooCommerce “Additional information” tab. Main SPECS tab stays on description.', 'mmi-amazon-price-sync' ),
					'id'      => MMI_APS_Settings::OPTION_SHOW_INFO_TAB,
					'type'    => 'checkbox',
					'default' => 'no',
				),
				array(
					'title'   => __( 'Show See Prices button', 'mmi-amazon-price-sync' ),
					'id'      => MMI_APS_Settings::OPTION_SHOW_SEE_PRICES,
					'type'    => 'checkbox',
					'default' => 'yes',
				),
				array(
					'title'   => __( 'Auto-prefer cheapest store (Flipkart)', 'mmi-amazon-price-sync' ),
					'desc'    => __( 'After Flipkart API is enabled: teaser and variant rows highlight Amazon vs Flipkart whichever is cheaper. Leave off until then.', 'mmi-amazon-price-sync' ),
					'id'      => MMI_APS_Settings::OPTION_AUTO_CHEAPEST_PLATFORM,
					'type'    => 'checkbox',
					'default' => 'no',
				),
				array(
					'type' => 'sectionend',
					'id'   => 'mmi_aps_storefront_options',
				),
			)
		);

		return apply_filters( 'woocommerce_get_settings_' . $this->id, $settings );
	}
}
